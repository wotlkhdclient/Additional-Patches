For enUS and enGB:
Put patch-v.mpq in Data folder.

For other langugaes:
Rename patch-xxxx-v.mpq as you language and put in your lang's folder.
Example patch-xxxx-v.mpq to patch-deDE-v.mpq and put in Data\deDE folder.